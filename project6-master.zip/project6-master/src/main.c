#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/ioctl.h>

#include "child.h"

#define MAX_FD 7




int main(void) {

	// used to store two ends of all pipe for child 1-5
	int fd1[2], fd2[2], fd3[2], fd4[2], fd5[2];
	// used to store two ends of pipe for child 5
	int* pipes[5];
	pipes[0] = fd1;
	pipes[1] = fd2;
	pipes[2] = fd3;
	pipes[3] = fd4;
	pipes[4] = fd5;
	int child_id[5];

	FILE *pFile;

	char buffer[100] ={'\0'};
	char message[150];
	int result;
	// 2 sets of file descriptors for input
	fd_set inputfds;
	// File to write to
	pFile = fopen("output.txt", "w");


	struct timeval start, timeout, temp, base;
	struct timespec start_time, ts;
	double timestamp;
	clock_gettime(CLOCK_MONOTONIC, &start_time);

	//pid_t parent_id, child_id[0], child_id[1], child_id[2], child_id[3], child_id[4];

	if (pipe(fd1) == -1) {
		fprintf(stderr, "Pipe failed");
		return 1;
	}
	if (pipe(fd2) == -1) {
		fprintf(stderr, "Pipe failed");
		return 1;
	}
	if (pipe(fd3) == -1) {
		fprintf(stderr, "Pipe failed");
		return 1;
	}
	if (pipe(fd4) == -1) {
		fprintf(stderr, "Pipe failed");
		return 1;
	}
	if (pipe(fd5) == -1) {
		fprintf(stderr, "Pipe failed");
		return 1;
	}

	// close(fd1[1]);
	// close(fd2[1]);
	// close(fd3[1]);
	// close(fd4[1]);
	// close(fd5[1]);

	//Add file descriptors to fd_set

	// FD_SET(fd1[READ_END], &inputfds);
	// FD_SET(fd2[READ_END], &inputfds);
	// FD_SET(fd3[READ_END], &inputfds);
	// FD_SET(fd4[READ_END], &inputfds);
	// FD_SET(fd5[READ_END], &inputfds);

	int max_fd = 0;
	for (int i = 0; i < 5; i++) {
		if (pipes[i][READ_END] > max_fd) 
			max_fd = pipes[i][READ_END];
		if (pipes[i][WRITE_END] > max_fd)
			max_fd = pipes[i][WRITE_END];
	}

	//Create child processes
	child_id[0] = fork();

	// Fork failed
	if (child_id[0] < 0) {
		fprintf(stderr, "Fork failed");
	}
	// Child Processes 1
	else if (child_id[0] == 0) {
		run_child(1, fd1);
	}
	// Parent process
	else {
		child_id[1] = fork();
		// Fork failed
		if (child_id[1] < 0) {
			fprintf(stderr, "Fork failed");
		}
		// Child Processes 2
		else if (child_id[1] == 0) {
			run_child(2, fd2);
		}
		// Parent process
		else {
			child_id[2] = fork();
			// Fork failed
			if (child_id[2] < 0) {
				fprintf(stderr, "Fork failed");
			}
			// Child Processes 3
			else if (child_id[2] == 0) {
				run_child(3, fd3);
			}
			// Parent process
			else {
				child_id[3] = fork();
				// Fork failed
				if (child_id[3] < 0) {
					fprintf(stderr, "Fork failed");
				}
				// Child Processes 4
				else if (child_id[3] == 0) {
					run_child(4, fd4);
				}
				// Parent process
				else {
					child_id[4] = fork();
					// Fork failed
					if (child_id[4] < 0) {
						fprintf(stderr, "Fork failed");
					}
					// Child Processes 5
					else if (child_id[4] == 0) {
						run_child_5(fd5);
					}
					// Parent process
					else {
						// Wait for child to send a string
						//perror("before while");
						while(1)
						{

							// needs to reset FD_sets each loop iteration
							FD_ZERO(&inputfds);
							for (int i = 0; i < 5; i++) 
								FD_SET(pipes[i][READ_END], &inputfds);

							timeout.tv_sec = 2;
							timeout.tv_usec = 0;

							// Get select() results. FD_SETSIZE = 1024 bits/FDs
							result = select(max_fd+1, &inputfds, NULL, NULL, &timeout);
							// Check the results.
							//   No input:  the program loops again.
							//   Got input: print what was typed, then terminate.
							//   Error:     terminate.

							if (result < 0) {
								perror("select");
								fclose(pFile);
								return 0;
							}
							else if (result == 0) {	 // checks every 2 seconds if all children are exited
								printf("nobody sent anything for 2 seconds :(\n");

								int alive_child = 0;
								int child_status;
								for (int i = 0; i < 5; i++) {
									waitpid(child_id[i], &child_status, WNOHANG);
									if (!WIFEXITED(child_status)) {
										printf("child is alive!! %i\n", i);
										alive_child = 1;
										break;
									}
								}
								if (!alive_child) {
									printf("all my children are dead :(, exiting...\n");
									exit(0);
								}
							}

							// Loop through file descriptors and check for input
							for (int i = 0; i < 5; i++) {

								if (FD_ISSET(pipes[i][READ_END], &inputfds)) {
									// printf("pipe[%i] is ready!\n", i);
									int bytes_read = read(pipes[i][READ_END], buffer, sizeof(buffer));
									clock_gettime(CLOCK_MONOTONIC, &ts);
									timestamp = (ts.tv_sec - start_time.tv_sec) + 1e-9*(ts.tv_nsec - start_time.tv_nsec);
									sprintf(message, "%.3f :: %s", timestamp, buffer);

									// printf("bytes_read: %i\n", bytes_read);
									// printf("RECEIVED: \'%s\'\n", buffer);
									int bytes_writ = fwrite(message, 1, strlen(message), pFile);
									// printf("bytes_writ: %i\n", bytes_writ);
									// fputs(buffer, pFile);
								}
							}
						}
					}
				}
			}
		}
	}
	fclose(pFile);
	return 0;
}
