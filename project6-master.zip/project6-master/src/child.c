#include "child.h"






// sends message containing elapsed time, child id, and message number through the pipe
void run_child(int id, int pipe[]) {
	//close(pipe[READ_END]);

	struct timespec start, ts;
	double elapsed_time = 0;
	clock_gettime(CLOCK_MONOTONIC, &start);

	size_t message_count = 1;
	char* message = malloc(100);
	while (elapsed_time < DURATION) {
		clock_gettime(CLOCK_MONOTONIC, &ts);
		elapsed_time = (ts.tv_sec - start.tv_sec) + 1e-9*(ts.tv_nsec - start.tv_nsec);
		sprintf(message, "%.3f: Child %i message %li\n", elapsed_time, id, message_count);
		write(pipe[WRITE_END], message, strlen(message) + 1);

		message_count += 1;
		sleep(rand() % 3);
	}

	free(message);
	close(pipe[WRITE_END]);
	exit(0);
}

// stuff for the 5th child
void run_child_5(int pipe[]) {

	fd_set readfds;
	int fd_stdin;
	int num_avail;

	fd_stdin = fileno(stdin);

	//Close the read end of the pipe
	//close(pipe[READ_END]);

	//Get starting time
	struct timeval start, timeout, temp, base;

	//Initialize Remaining time structure
	// remaining.tv_sec = DURATION;
	// remaining.tv_usec = 0;

	// temp.tv_sec = 0;
	// temp.tv_usec = 0;

	//Create buffers for the message
	char buffer[100] = {'\0'};
	char message[436] = {'\0'};

	//Get the initial starting time
	gettimeofday(&start, NULL);

	base.tv_sec = timeout.tv_sec = DURATION;
	base.tv_usec = timeout.tv_usec = 0;
	while(timeout.tv_sec > 0)
	{
		FD_ZERO(&readfds);
		FD_SET(fileno(stdin), &readfds);

		fflush(stdout);
		num_avail = select(fd_stdin + 1, &readfds, NULL, NULL, &timeout);
		switch(num_avail)
		{
			case -1:
				//printf("Child5 done");
				close(pipe[WRITE_END]);
				exit(0);
			case 0:
				gettimeofday(&temp, NULL);
				timersub(&temp, &start, &timeout);
				timersub(&base, &timeout, &timeout);
				//printf("Child5 done");
				close(pipe[WRITE_END]);
				exit(0);
				return;
			default:
				fgets(buffer, sizeof(buffer), stdin);

				gettimeofday(&temp, NULL);
				timersub(&temp, &start, &timeout);
				sprintf(message, "%.3f: Child 5: %s", timeout.tv_sec + (timeout.tv_usec * 1e-6), buffer);
				timersub(&base, &timeout, &timeout);
				//printf(message);
				write(pipe[WRITE_END], message, strlen(message) + 1);
				continue;
		}
	}
	close(pipe[WRITE_END]);
	exit(0);
}
