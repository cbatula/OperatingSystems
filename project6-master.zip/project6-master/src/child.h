#include <string.h>
#include <fcntl.h>
#include <sys/time.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#define READ_END 0
#define WRITE_END 1
#define DURATION 30




void run_child(int id, int pipe[]);

void run_child_5(int pipe[]);
