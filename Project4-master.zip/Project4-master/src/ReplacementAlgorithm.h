#pragma once

#include <string>
#include <iostream>
#include <ctime>
#include <chrono>
#include <map>
#include <deque>
#include <climits>


class ReplacementAlgorithm
{
public:
	// called when we make an access
	virtual void access(size_t page_id) = 0;

	// calculate which page should be evicted
	virtual size_t evict() = 0;

	virtual std::string name() = 0;

	virtual void removePage(size_t id) { };
};

typedef std::shared_ptr<ReplacementAlgorithm> ReplacementAlgoPtr;

class RandomReplacement : public ReplacementAlgorithm
{
public:
	void access(size_t page_id)
	{
		//std::cout << "Access " << page_id << std::endl;
	}

	virtual size_t evict()
	{
		return rand() % 100;
	}

	std::string name()
	{
		return "RandomReplacement";
	}
};

class LRUReplacement : public ReplacementAlgorithm
{
public:
	std::map<size_t, std::chrono::steady_clock::time_point> counter;
	void access(size_t page_id)
	{
		//std::cout << "Access Page ID: " << page_id << std::endl;
		counter[page_id] = std::chrono::steady_clock::now();
	}

	virtual size_t evict()
	{
		size_t page_to_evict;
		std::chrono::steady_clock::time_point min = std::chrono::steady_clock::now();
		for (auto page:counter) {
			if (page.second <= min) {
				min = page.second;
				page_to_evict = page.first;
			}
		}
		counter.erase(page_to_evict);
		return page_to_evict;
	}

	std::string name()
	{
		return "LRUReplacement";
	}

	virtual void removePage(size_t id) {
		counter.erase(id);
	}
};

class LFUReplacement : public ReplacementAlgorithm
{
public:
	std::map<size_t, int> counter;
	void access(size_t page_id)
	{
		//std::cout << "Access Page ID: " << page_id << std::endl;
		counter[page_id] += 1;
	}

	virtual size_t evict()
	{
		size_t page_to_evict;
		int min_counter = INT_MAX;
		int index = 0;
		for (auto page:counter) {
			  if (index == 0 || min_counter > page.second) {
					  min_counter = page.second;
					  page_to_evict = page.first;
				}
			  index += 1;
		}
		counter.erase(page_to_evict);
		return page_to_evict;
	}

	std::string name()
	{
		return "LFUReplacement";
	}

	virtual void removePage(size_t id) {
		counter.erase(id);
	}
};

class MFUReplacement : public ReplacementAlgorithm
{
public:
	std::map<size_t, int> cnt;
	std::string name()
	{
		return "MFUReplacement";
	}
	void access(size_t page_id)
	{
		//std::cout << "Accessed PageID: "<< page_id << std::endl;
		cnt[page_id] += 1;
	}
	virtual size_t evict()
	{
		size_t e_page;
		size_t ind = 0;
		size_t local_cnt=0;
		for(auto page:cnt)
		{
			if(ind==0 || local_cnt < page.second)
			{
				e_page = page.first;
				local_cnt = page.second;
			}
			ind=ind+1;
		}
		cnt.erase(e_page);
		return e_page;
	}

	virtual void removePage(size_t id) {
		cnt.erase(id);
	}
};

class FIFOReplacement : public ReplacementAlgorithm
{
public:
	std::map<size_t, bool> active;
	std::deque<size_t> page_order;

	void access(size_t page_id)
	{
		if(!active[page_id])
		{
			page_order.push_back(page_id);
			active[page_id] = true;
		}
		//std::cout << "Access Page ID: " << page_id << std::endl;
		active[page_id] = true;
	}

	virtual size_t evict()
	{
		size_t evicted_page;
		evicted_page = page_order.front();
		page_order.pop_front();
		active[evicted_page] = false;
		return evicted_page;
	}

	std::string name()
	{
		return "FIFOReplacement";
	}

	virtual void removePage(size_t id)
	{
		active[id] = false;

		for (auto it = page_order.begin(); it != page_order.end(); ++it)
		{
			if(*it == id)
			{
				page_order.erase(it);
				break;
			}
		}
	};
};
