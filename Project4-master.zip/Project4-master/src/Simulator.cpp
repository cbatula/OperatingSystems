#include "Simulator.h"

Simulator::Simulator(size_t free_page_count,
					 std::list<Job> job_queue,
					 ReplacementAlgoPtr replacement)
	: pages(free_page_count), job_queue(job_queue), replacement(replacement),
	  total_started(0)
{
	for (size_t i = 0; i < pages.size(); i++)
	{

		pages[i] = PagePtr(new Page(ProcPtr(), 0, i));
	}
}

void Simulator::tick()
{

	tryStartJobs();

	tickJobs();

	removeCompleted();

	time_ms += 100;
}

void Simulator::tryStartJobs()
{
	if (freePages() < 4)
	{
		return;
	}

	if (job_queue.size() == 0)
	{
		return;
	}

	if (job_queue.front().arrival_time_ms > time_ms)
	{
		return;
	}

	total_started++;
	startJob(job_queue.front());
	job_queue.pop_front();
}

void Simulator::startJob(const Job &job)
{
	ProcPtr new_proc(new Process(job));
	new_proc->start_time = time_ms;

	// **** this is already done in tickJobs() ?? ****
	// not really sure what to put here
	// Page p = nextFreePage();
	// new_proc->swapIn(0);
	// p.owner = new_proc;
	// p.owner_offset = 0;
	// replacement->access(0);

	// TODO: do pages start in memory?
	// for (size_t i = 0; i < job.proc_size; i++)
	// {
	// 	if(freePages() == 0)
	// 	{
	// 		break;
	// 	}

	// 	new_proc->swapIn(i);
	// 	auto &nextFree = nextFreePage();
	// 	nextFree = new_proc;
	// }

	running.push_back(new_proc);
	// TODO: print <time stamp, process name, Enter/exit, Sizein Pages, Service Duration, Memory-map>
	std::cout << "PROC_START_TIME: " << std::to_string(time_ms);								  // 1
	std::cout << " PROC_NAME: " << new_proc->job.name << " ENTER ";								  //2
	std::cout << " PAGE_SIZE: " << std::to_string(new_proc->job.proc_size);						  // 3
	std::cout << " SERVICE_DURATION (MS): " << std::to_string(new_proc->job.service_duration_ms); // 4
	std::cout << "\n"
			  << getMemMapString() << std::endl; // 5
}

void Simulator::tickJobs()
{
	for (auto &&proc : running)
	{
		auto access_page_id = proc->getRandomAccess();
		auto resident = proc->isSwappedIn(access_page_id);

		size_t to_evict = 0;

		//auto to_evict = replacement->evict();
		bool page_in_mem_cap = proc->page_in_mem[access_page_id]; 
		total_count += 1;  // mem hit rate stats
		if (!resident)
		{
			miss_count += 1;  // mem hit rate stats
			if (freePages() == 0)
			{
				to_evict = replacement->evict();
				auto page = pages[to_evict];
				page->owner->swapOut(page->owner_page_id);
				page->owner = proc;
				page->owner_page_id = access_page_id;
				proc->swapIn(access_page_id);
			}
			else
			{
				auto page = nextFreePage();
				page->owner = proc;
				page->owner_page_id = access_page_id;
				proc->swapIn(access_page_id);
			}
		}
		else
			hit_count += 1;  // mem hit rate stats

		auto pageId = getPageId(proc, access_page_id);

		replacement->access(pageId);

		proc->remaining_time_ms -= 100;
		// TODO: print <time-stamp in seconds, process Name, page-referenced, if-Page-in-memory, which process/page number will be evictedif needed>
		std::cout << "MEM_REF: " << std::to_string(time_ms) << " PROC_NAME: " << proc->job.name << " PAGE_ID: " << std::to_string(access_page_id) << " IF_IN_MEM: " << std::to_string(page_in_mem_cap) << " TO_EVICT: " << to_evict << std::endl;
	}
}

void Simulator::removeCompleted()
{
	auto tmp = running;
	running.clear();
	for (auto &&proc : tmp)
	{
		if (proc->isCompleted())
		{
			freeResidentPages(proc);
			std::cout << "PROC_END: " << std::to_string(time_ms) << " PROC_NAME: " << proc->job.name << " EXIT PROC_EXIT_TIME: " << std::to_string(proc->start_time + proc->job.service_duration_ms) << " PROC_SIZE: " << std::to_string(proc->job.proc_size) << " PROC_DUR: " << std::to_string(proc->job.service_duration_ms) << std::endl
					  << getMemMapString() << std::endl;
		}
		else
		{
			running.push_back(proc);
		}
	}
}

size_t Simulator::freePages()
{
	size_t i = 0;
	for (auto &&pg : pages)
	{
		if (!pg->present())
		{
			i++;
		}
	}
	return i;
}

PagePtr Simulator::nextFreePage()
{
	for (auto &&pg : pages)
	{
		if (!pg->present())
		{
			return pg;
		}
	}

	throw std::runtime_error("No free pages");
}

void Simulator::freeResidentPages(ProcPtr proc)
{
	for (auto &&page : pages)
	{
		if (proc == page->owner)
		{
			replacement->removePage(page->page_id);
			page->owner = ProcPtr();
			page->owner_page_id = 0;
		}
	}
}

size_t Simulator::getTimeMilliseconds()
{
	return time_ms;
}

std::string Simulator::getMemMapString()
{
	std::string mem_map = "";
	for (size_t i = 0; i < pages.size(); i++)
	{
		if (pages[i]->owner == nullptr)
			mem_map += ".";
		else
			mem_map += pages[i]->owner->job.name;
		mem_map += ",";
	}
	return mem_map;
}

size_t Simulator::totalStarted()
{
	return total_started;
}
float Simulator::hit_ratio() {
	return (float)hit_count / total_count;
}
float Simulator::miss_ratio() {
	return (float)miss_count / total_count;
}

size_t Simulator::getPageId(ProcPtr proc, size_t proc_page_id)
{
	for (auto &&page : pages)
	{
		if (page->owner == proc && page->owner_page_id == proc_page_id)
		{
			return page->page_id;
		}
	}
}
