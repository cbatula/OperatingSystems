#pragma once

#include <vector>
#include <list>
#include <memory>
#include <iostream>

#include "Job.h"
#include "Process.h"
#include "ReplacementAlgorithm.h"
#include "Page.h"

class Simulator
{
	size_t time_ms = 0;
	std::vector<PagePtr> pages;
	std::vector<ProcPtr> running;
	std::list<Job> job_queue;

	size_t total_started = 0;
	size_t hit_count = 0;
	size_t miss_count = 0;
	size_t total_count = 0;

	const ReplacementAlgoPtr replacement;

public:
	Simulator(size_t free_page_count,
			  std::list<Job> job_queue,
			  ReplacementAlgoPtr replacement);

	void tick();

	void tryStartJobs();

	void startJob(const Job &job);

	void tickJobs();

	void removeCompleted();

	size_t freePages();

	PagePtr nextFreePage();

	void freeResidentPages(ProcPtr proc);

	size_t getTimeMilliseconds();

	std::string getMemMapString();

	size_t totalStarted();

	float hit_ratio();
	
	float miss_ratio();

	size_t getPageId(ProcPtr proc, size_t proc_page_id);
};
