#!/bin/bash

# runs g++ with everything
g++ -g Customer.cpp main.cpp Seller.cpp ticket_manager.cpp -pthread
 

