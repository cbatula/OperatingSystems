#include <iostream>
#include <assert.h>
#include "ticket_manager.h"
#include <thread>
#include <array>
#include "Seller.h"
#include "Customer.h"

int main(int argc, char *argv[]); 
