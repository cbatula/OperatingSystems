#ifndef SJF_H
#define SJF_H
#include "../process.h"
#include "../workload.h"

void run_sjf();

#endif
