#ifndef FCFS_H
#define FCFS_H
#include "../process.h"
#include "../workload.h"

void run_fcfs();

void run_one_fcfs();

#endif
