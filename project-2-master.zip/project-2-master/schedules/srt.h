#ifndef SRT_H
#define SRT_H
#include "../process.h"
#include "../workload.h"

void run_srt();

#endif
