#ifndef RUN_H
#define RUN_H
#include "process.h"
#include "workload.h"

void run_schedule(int schedule);

// void run_fcfs();

#endif
