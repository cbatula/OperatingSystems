#ifndef PROCESS
#define PROCESS

char get_name();

void seed_process_random(char c);

float get_arrival_time();

float get_service_time();

int get_priority();

#endif
